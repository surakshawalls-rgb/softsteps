import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { Auth } from '../auth/auth';

export const adminGuard: CanActivateFn = async () => {
  const auth = inject(Auth);
  const router = inject(Router);

  if (!(await auth.isAuthenticated())) {
    return router.createUrlTree(['/admin/access-denied']);
  }

  if (!(await auth.isAdmin())) {
    return router.createUrlTree(['/admin/access-denied']);
  }

  return true;
};
