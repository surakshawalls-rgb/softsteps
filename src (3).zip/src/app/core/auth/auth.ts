import { Injectable } from '@angular/core';

import { environment } from '../../../environments/environment';
import { SupabaseService } from '../services/supabase.service';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  constructor(private readonly supabaseService: SupabaseService) {}

  async isAuthenticated(): Promise<boolean> {
    const { data, error } = await this.supabaseService.client.auth.getSession();

    if (error) {
      return false;
    }

    return !!data.session;
  }

  async isAdmin(): Promise<boolean> {
    const { data, error } = await this.supabaseService.client.auth.getSession();

    if (error || !data.session?.user) {
      return false;
    }

    const user = data.session.user;
    const userEmail = user.email?.toLowerCase() ?? '';
    const allowedEmails = (environment.admin?.allowedEmails ?? [])
      .map((email: string) => email.trim().toLowerCase())
      .filter(Boolean);
    const userRole = user.app_metadata?.['role'] ?? user.user_metadata?.['role'];
    const isConfiguredAdmin = Boolean(
      userRole === 'admin' ||
        user.app_metadata?.['is_admin'] ||
        user.user_metadata?.['is_admin'] ||
        (userEmail && allowedEmails.includes(userEmail)),
    );

    return isConfiguredAdmin;
  }
}
