import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin-access-denied',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './admin-access-denied.html',
  styleUrl: './admin-access-denied.css',
})
export class AdminAccessDeniedPage {
}
