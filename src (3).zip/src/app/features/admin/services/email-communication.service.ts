import { Injectable } from '@angular/core';

import { environment } from '../../../../environments/environment';
import { SupabaseService } from '../../../core/services/supabase.service';

export interface EmailSendRequest {
  to: string;
  subject: string;
  body: string;
  senderName?: string;
  senderEmail?: string;
}

export interface EmailSendResult {
  ok: boolean;
  configured: boolean;
  message: string;
}

@Injectable({ providedIn: 'root' })
export class EmailCommunicationService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async sendEmail(request: EmailSendRequest): Promise<EmailSendResult> {
    const provider = environment.adminMessaging?.provider ?? 'none';

    if (provider === 'none' || provider === 'not-configured') {
      return {
        ok: false,
        configured: false,
        message:
          'Email delivery is not configured. Add RESEND_API_KEY and RESEND_FROM_EMAIL to the Supabase Edge Function secrets and deploy the send-admin-email edge function.',
      };
    }

    try {
      const { data, error } = await this.supabaseService.client.functions.invoke('send-admin-email', {
        body: {
          to: request.to,
          subject: request.subject,
          body: request.body,
          senderName: request.senderName ?? 'Soft Steps Carpets & Rugs',
          senderEmail: request.senderEmail ?? 'info@softstepscarpets.com',
        },
      });

      if (error) {
        return {
          ok: false,
          configured: true,
          message: error.message ?? 'The email request could not be accepted by the delivery service.',
        };
      }

      if (!data?.success) {
        return {
          ok: false,
          configured: true,
          message: data?.message ?? 'The email request could not be completed.',
        };
      }

      return {
        ok: true,
        configured: true,
        message: data?.message ?? 'Email sent successfully.',
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unexpected error while sending email.';

      return {
        ok: false,
        configured: true,
        message,
      };
    }
  }
}
